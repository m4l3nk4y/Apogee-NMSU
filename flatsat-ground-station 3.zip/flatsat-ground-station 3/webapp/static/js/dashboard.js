const $=id=>document.getElementById(id);
let connected=false, serialNumber=null, lastStatus=null;
function log(id,msg){const el=$(id);el.textContent=`[${new Date().toLocaleTimeString()}] ${msg}\n`+el.textContent;}
function setState(id,value,kind=''){const el=$(id);el.textContent=value;el.className='state '+kind;}
function gate(){document.querySelectorAll('.hw-action').forEach(b=>b.disabled=!connected);$('disconnect-btn').disabled=!connected;}
function health(text,kind,detail){$('health-value').textContent=text;$('health-value').style.color=kind==='pass'?'var(--green)':kind==='fail'?'var(--red)':'var(--yellow)';$('health-detail').textContent=detail;}
async function api(url,opts={}){const r=await fetch(url,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||`HTTP ${r.status}`);return d;}
async function refreshAll(){
 try{const d=await api('/api/hardware/status');connected=d.mode==='hardware';serialNumber=d.serial_number||null;
 $('connection-label').textContent=connected?'HARDWARE CONNECTED':d.mode==='simulated'?'SIMULATION ONLY':'DISCONNECTED';
 $('connection-dot').className=connected?'online':'offline';$('serial-label').textContent=serialNumber?`Serial: ${serialNumber}`:'No device connected';
 $('connection-note').textContent=connected?'Hardware link active. Satellite controls are enabled.':'Connect a physical FlatSat by USB. Simulation does not enable satellite controls.';
 $('radio-value').textContent=connected?'USB LINK UP':'OFFLINE';gate();
 if(!connected){health('OFFLINE','fail','No physical FlatSat connection');$('battery-value').textContent='—';$('flight-value').textContent='—';['temperature','pressure','humidity'].forEach(x=>$(x).textContent='—');return;}
 const s=await api('/api/satellite/status');lastStatus=s;
 $('battery-value').textContent=s.battery_mv?`${(s.battery_mv/1000).toFixed(2)} V`:'—';
 $('flight-value').textContent=s.flight||s.local?.flight||s.mode||'—';
 const sat=s.satellite||{};const remote=s.remote||{};
 const available=remote.available===true||sat.available===true;
 health(available?'NOMINAL':'CONNECTED','warn',available?'Remote telemetry is available':'USB connected; waiting for remote telemetry');
 }catch(e){connected=false;gate();$('connection-label').textContent='STATUS ERROR';$('connection-dot').className='offline';health('UNKNOWN','fail',e.message);}
}
async function scanDevices(){try{const d=await api('/api/hardware/scan',{method:'POST'});const sel=$('device-select');sel.innerHTML='';(d.devices||[]).forEach(x=>{const o=document.createElement('option');o.value=x.serial_number;o.textContent=`${x.serial_number} (${x.health})`;sel.appendChild(o)});sel.hidden=!d.devices?.length;$('connect-btn').disabled=!d.devices?.length;if(!d.devices?.length)log('diagnostic-log','No FlatSat devices found.');}catch(e){log('diagnostic-log',`USB scan failed: ${e.message}`)}}
async function connectDevice(){const sn=$('device-select').value;if(!sn)return;try{const d=await api('/api/hardware/connect',{method:'POST',body:JSON.stringify({serial_number:sn,radio_mode:'auto',device_role:'auto'})});if(d.mode!=='hardware')throw new Error(d.error||'Connection did not enter hardware mode');await refreshAll();}catch(e){log('diagnostic-log',`Connect failed: ${e.message}`)}}
async function disconnectDevice(){try{await api('/api/hardware/disconnect',{method:'POST'});await refreshAll();}catch(e){log('diagnostic-log',`Disconnect failed: ${e.message}`)}}
async function runSensorTest(){if(!connected)return;setState('sensor-test-state','RUNNING','warn');try{const d=await api('/api/satellite/sensors');if(!d.available)throw new Error('No remote sensor telemetry available');$('temperature').textContent=d.temperature??'—';$('pressure').textContent=d.pressure??'—';$('humidity').textContent=d.humidity??'—';setState('sensor-test-state','RESPONSE OK','pass');$('sensor-result').textContent=`Sensor data received (${d.source||'unknown'} source).`;log('diagnostic-log','Atmospheric sensor request returned data.');}catch(e){setState('sensor-test-state','NO DATA','fail');$('sensor-result').textContent=e.message;log('diagnostic-log',`Sensor test: ${e.message}`)}}
async function sendTc(opcode,data=''){return api('/api/radio/send_tc',{method:'POST',body:JSON.stringify({opcode,data})});}
async function sendCommand(){if(!connected)return;const op=$('command-select').value;try{const d=await sendTc(op);log('command-log',`Command 0x${op} submitted: ${d.status||'response received'}${d.frame_hex?' · '+d.frame_hex:''}`);if(op==='10')setState('radio-test-state','SENT','pass');}catch(e){log('command-log',`Command rejected/failed: ${e.message}`);if(op==='10')setState('radio-test-state','FAILED','fail')}}
async function sendCustomCommand(){if(!connected)return;const op=$('custom-opcode').value.trim().replace(/^0x/i,'');const data=$('custom-data').value.trim().replace(/\s+/g,'');if(!/^[0-9a-fA-F]{1,2}$/.test(op)){log('command-log','Opcode must be 1–2 hexadecimal digits.');return;}if(data&&!/^(?:[0-9a-fA-F]{2})+$/.test(data)){log('command-log','Payload must contain complete hexadecimal byte pairs.');return;}if(!confirm(`Send custom telecommand opcode 0x${op.toUpperCase()}?`))return;try{const d=await sendTc(op,data);log('command-log',`Custom command 0x${op.toUpperCase()} submitted: ${d.status||'ok'}`)}catch(e){log('command-log',`Custom command failed: ${e.message}`)}}
async function runOverallTest(){if(!connected)return;setState('overall-test-state','RUNNING','warn');await refreshAll();if(!connected){setState('overall-test-state','FAILED','fail');return;}try{const d=await api('/api/satellite/status');const ok=!!d&&!!(d.local||d.satellite);setState('overall-test-state',ok?'STATUS OK':'NO DATA',ok?'pass':'fail');health(ok?'CONNECTED':'UNKNOWN',ok?'pass':'fail',ok?'Satellite status endpoint responded':'No usable status returned');log('diagnostic-log',ok?'Overall status check passed (API response received).':'Overall status check returned no usable data.');}catch(e){setState('overall-test-state','FAILED','fail');log('diagnostic-log',`Overall test failed: ${e.message}`)}}
async function refreshSensors(){if(connected)await runSensorTest();}
async function refresh(){await refreshAll();}
async function init(){await refreshAll();setInterval(refreshAll,5000);}
init();
