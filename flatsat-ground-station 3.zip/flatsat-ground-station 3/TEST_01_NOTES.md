# Test 01 dashboard

This is an update to the existing Flask ground-station project. It is not firmware.

## What changed
- Reworked `webapp/templates/dashboard.html` into the Test 01 mission dashboard.
- Replaced dashboard CSS and JavaScript in `webapp/static/`.
- Reuses existing authenticated endpoints for USB scan/connect/disconnect, satellite status, sensors, and telecommands.
- Satellite actions are disabled unless `/api/hardware/status` reports physical `hardware` mode.
- Radiation is explicitly marked unavailable.

## Known limitations
- Text messaging and addressing a second FlatSat are not implemented: the uploaded ground-station source does not define a text-message wire format or destination address.
- The dashboard offers only telecommands already exposed by the current backend (PING 0x10 and READ_SENSOR 0x20), plus custom opcode/payload entry subject to server-side role permissions.
- A radio command being accepted by the ground station is not proof that the remote satellite acknowledged it.
- The current status API does not expose a complete engineering health score; the dashboard distinguishes offline, connected, and telemetry-available rather than inventing a health value.

## Validation performed
- JavaScript syntax check (`node --check`): passed.
- Python source compilation (`compile()` over all `.py` files): passed.
- Full pytest suite could not be collected in this execution environment because Flask and Flask-SocketIO are not installed (`ModuleNotFoundError`). Install project requirements in the existing `.venv` and rerun tests there.
- Physical USB and RF testing requires the user's FlatSat hardware and cannot be performed from this environment.
